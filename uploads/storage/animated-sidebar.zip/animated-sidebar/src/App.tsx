import { Sidebar } from './sidebar/Sidebar';

function App() {
  return (
    <main>
      <Sidebar />
    </main>
  );
}

export default App;

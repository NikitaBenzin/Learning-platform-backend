import { atom } from 'jotai';

export const isSidebarOpenAtom = atom(false);

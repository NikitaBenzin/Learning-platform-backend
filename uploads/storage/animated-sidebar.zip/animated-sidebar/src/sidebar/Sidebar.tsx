import { Menu } from './menu/Menu';
import styles from './Sidebar.module.scss';

export const Sidebar = () => {
  return (
    <aside className={styles.sidebar}>
      <Menu />
    </aside>
  );
};

import {
  Bookmark,
  Home,
  LucideIcon,
  Search,
  Settings,
  Users,
} from 'lucide-react';

export interface IMenuItem {
  icon: LucideIcon;
  name: string;
  link: string;
}

export const MENU: IMenuItem[] = [
  {
    icon: Home,
    name: 'Home',
    link: '/home',
  },
  {
    icon: Search,
    name: 'Search',
    link: '/search',
  },
  {
    icon: Settings,
    name: 'Settings',
    link: '/settings',
  },
  {
    icon: Users,
    name: 'Users',
    link: '/users',
  },
  {
    icon: Bookmark,
    name: 'Bookmarks',
    link: '/bookmarks',
  },
];

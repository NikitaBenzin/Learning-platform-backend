import { useWindowSize } from '@uidotdev/usehooks';
import { m } from 'framer-motion';
import { useAtom } from 'jotai';
import { SidebarClose, SidebarOpen } from 'lucide-react';
import { useHotkeys } from 'react-hotkeys-hook';
import { isSidebarOpenAtom } from '../../store';
import { MENU } from './menu.data';
import styles from './Menu.module.scss';
import { MenuItem } from './MenuItem';

export const Menu = () => {
  const [isSidebarOpen, setIsSidebarOpen] = useAtom(isSidebarOpenAtom);
  useHotkeys('[', () => setIsSidebarOpen(!isSidebarOpen));
  const { width } = useWindowSize();
  const screenWidth = width! > 600 ? 75 : 48;

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  return (
    <m.nav
      className={styles.menu}
      animate={{ width: isSidebarOpen ? 208 : screenWidth }}
      transition={{ type: 'spring', stiffness: 120, damping: 20 }}
    >
      <button className={styles.sidebarToggle} onClick={toggleSidebar}>
        {isSidebarOpen ? <SidebarClose /> : <SidebarOpen />}
      </button>
      {MENU.map(item => (
        <MenuItem item={item} key={item.link} />
      ))}
    </m.nav>
  );
};

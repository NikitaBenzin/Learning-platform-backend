import { m } from 'framer-motion';
import { useAtomValue } from 'jotai';
import { isSidebarOpenAtom } from '../../store';
import { IMenuItem } from './menu.data';

export const MenuItem = ({ item }: { item: IMenuItem }) => {
  const isSidebarOpen = useAtomValue(isSidebarOpenAtom);

  return (
    <a href='#' rel='noreferrer noopener' target='_blank'>
      <item.icon />
      {isSidebarOpen && (
        <m.span
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{
            duration: 1.25,
          }}
        >
          {item.name}
        </m.span>
      )}
    </a>
  );
};
